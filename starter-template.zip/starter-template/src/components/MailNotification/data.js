export const notifications = [
  {
    id: 1,
    image: require('assets/images/avatar/a5.png'),
    name: "Domnic Brown",
    time: "6:19 PM",
    message: "There are many variations of passages of...",
    badge: 5
  },
  {
    id: 2,
    image: require('assets/images/avatar/a6.png'),
    name: "John Smith",
    time: "4:18 PM",
    message: "Lorem Ipsum is simply dummy text of the...",
  },
  {
    id: 3,
    image: require('assets/images/avatar/john-smith.png'),
    name: "John Smith",
    time: "7:10 PM",
    message: "The point of using Lorem Ipsum is that it has a...",
    badge: 8
  },
  {
    id: 4,
    image: require('assets/images/avatar/stella-johnson.png'),
    name: "alex dolgove",
    time: "5:10 PM",
    message: "It is a long established fact that a reader will...",
  },
  {
    id: 5,
    image: require('assets/images/avatar/a7.png'),
    name: "Domnic Harris",
    time: "7:35 PM",
    message: "All the Lorem Ipsum generators on the...",
    badge: 3
  }
];
