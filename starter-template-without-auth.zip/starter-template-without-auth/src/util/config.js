module.exports = {
  footerText: 'Copyright Company Name © 2018',
}
